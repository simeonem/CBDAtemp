# ui.R
require(shiny)
library(DT)

shinyUI(
  DT::dataTableOutput('mytable')
)

# Server.R
library(shiny)
library(DT)

server <- function(input, output) {
dat <- data.frame(
  country = c('USA','China'),
  flag = c('<img src="test.png" height="52"></img>',
           '<img src="http://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Flag_of_the_People%27s_Republic_of_China.svg/200px-Flag_of_the_People%27s_Republic_of_China.svg.png" height="52"></img>'
           )
)

shinyServer(function(input, output){
  output$mytable <- DT::renderDataTable({

    DT::datatable(dat)
  })
})
}
# Run the application 
shinyApp(ui=NULL, server = server)

library(magick)
frink <- image_read("SOCR_UKBB_Labels_Sprite_image.png")
#( info <- image_info(frink) )
# PNG     2800   2800 Gray       FALSE  5099892 72x72
#frink_crop <- image_crop(frink, sprintf("28x28+28+28"))

crops <- list()
for (i in 1:99)
{
  for (j in 1:99)
  {
    ## This command splits the large image of 2800x2800 pixels,
    ## into small pictures of 28x28 pixels each.
    crops <- c(crops,image_crop(frink, sprintf("28x28+%d+%d",28*i,28*j)))
  }
}
length(crops) # 9801
# for (j in 1:length(crops))
#      {
#        eval(parse(text=paste0("image_write(crops[[",j,"]],path = 'MRI_",j,".png')")))
# }

crops <- list()
for (x in seq(0,info$width%/%28*28,28)) 
{
  #for (y in seq(0,info$height%/%28*28,28)) 
    for (y in c(0,28)) 
    {
    crops <- c(crops, image_crop(frink, sprintf("28x28+%d+%d", x, y)))
  }
}



library(imager)
im_all=load.image("SOCR_UKBB_Labels_Sprite_image.png") %>% plot
imsplit(im_all,"x",-28) %>% plot