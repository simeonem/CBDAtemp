# This is a SOCR GrayRain VirtualHospital - SimPatient Shiny web application.
# You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#   https://www.socr.umich.edu/projects/GrayRain/virtualHospital.html#
#   https://shiny.med.umich.edu/apps/dinov/GrayRain_VirtualHospital
#   http://myumi.ch/qgY7v

library(shiny)
library(randomForest)
library(DT)
library(ggplot2)
library(plotly)
library(tidyverse)
library(tokenizers)
library(doSNOW)
library(tibble)
library(charlatan)
library(magick)
library(truncnorm)
# packages <- c("shiny","randomForest","doSNOW","DT","ggplot2",
#               "plotly","tidyverse","tokenizers")
# ipak <- function(pkg){
#   new.pkg <- pkg[!(pkg %in% installed.packages()[, "Package"])]
#   if (length(new.pkg))
#     install.packages(new.pkg, dependencies = TRUE, repos='http://cran.rstudio.com/')
#   #install.packages(new.pkg, dependencies = TRUE, repos='https://cran.r-project.org/')
#   #install.packages(new.pkg, dependencies = TRUE, repos= NULL)
#   sapply(pkg, require, character.only = TRUE)
# }
# ipak(packages)

# Data sifter
source("./R_src/rpacksifter-2_with_notes.R")

options(DT.options = list(pageLength = 10))

# load("MIMIC_1000_199.RData")
# MIMIC_data <- MIMIC_1000_199
#save(MIMIC_1000_278,unstructured_list,file = "MIMIC_1000_278.RData")
# load("MIMIC_1000_278.RData")
# MIMIC_data <- MIMIC_1000_278
load("MIMIC_1000_278_new.RData")
MIMIC_data <- MIMIC_1000_278_new

# data_temp=MIMIC_data
# a=ifelse((is.na(data_temp)),1,0);
# 100*sum(a)/(dim(data_temp)[1]*dim(data_temp)[2])

itemColName <- colnames(MIMIC_data)[-c(1:2)]

TempICD9Strings <- c("001","002","002.0","002.1","002.2","002.3","002.9","003","003.0")
TempICD10Strings <- c("A00","A01","A01.0","A01.1","A01.2","A01.3","A01.4","A02","A03","A03.0")

itemLabel <- map_chr(itemColName, function(colName)  {
  paste(colName,
        sample(TempICD9Strings, 1,replace = TRUE),
        sample(TempICD10Strings, 1,replace= TRUE),
        sep = " - ")
})
names(itemColName) <- itemLabel


##################################### UI ####################################

ui <- tagList(
  fluidPage(
    tags$head(tags$link(href = "gray-rain.css", rel = "stylesheet")),
    
    hr(),
    
    # ----------------------- Tab Panels ----------------------- #
  
    
    
    tabsetPanel(
      # ----------------------- Synthetic Patients Generation Tab ----------------------- #
      tabPanel(
        title = paste0("Synthetic Patients Generation ", intToUtf8(0x0000226B)),
        sidebarPanel(width = 3,
          h3("Synthetic Patients Inputs"),
          numericInput("N", "# of virtual patients", 50, min = 0),
          numericInput("K", "Total # of features", 5, min = 0),
          selectizeInput("icd9_selection","Search and Select ICD9-ICD10 Codes", 
                         choices = itemColName,
                         multiple = TRUE),
          div(class="button-group",
              actionButton("vh_generate", "Generate Synthetic Dataset",
                           style = "color: white;background-color: blue"),
              actionButton("vh_selectAll", "Select All"),
              actionButton("vh_reset", "Reset"),
              downloadButton("vh_save", "Save"),
              actionButton("vh_readme", "ReadMe/Help")
          ),
          checkboxGroupInput(inputId ="vh_option", label = "Must/Must not contain:",
                             choices = c("Doctor notes" = "dot",
                                         "Images" = "img")#,selected = c("dot","img")
          )
        ),
        mainPanel(width = 9,
          h2("Synthetic Patients Data & Statistics"),
          
          uiOutput("Sythetic")
          
      ),
      ),
      # ----------------------- Data Obfuscation Tab ----------------------- #
      tabPanel(
        title = paste0("Data Obfuscation ", intToUtf8(0x0000226B)),
        sidebarPanel(
          width = 3,
          radioButtons("ob_syn_level", 
                       "LEVELS OF OBFUSCATION", 
                       choiceNames = c("LARGE - Extremely Low Disclosure Risk", "MEDIUM - Low Disclosure Risk","SMALL - Minimal Disclosure Risk"),
                       choiceValues = c("large","medium", "small"),
                       # choiceNames = c("small", "medium", "large", "indepedent"),
                       # choiceValues = c("small", "medium", "large", "indep"),
                       selected = "small"
          ),
          h3("Obfuscate Synthetic Dataset (displayed)"),
          div(class = "button-group",
              actionButton("ob_syn_obf", "Obfuscate Synthetic Dataset",
                           style = "color: white;background-color: blue"),
              actionButton("ob_syn_reset", "Reset"),
              downloadButton("ob_syn_save", "Save"),
          ),
          hr(),
          h3("Obfuscate Uploaded Dataset (not displayed)"),
          fileInput(
            "ob_file",
            "Choose CSV File",
            accept = c("text/csv",
                       "text/comma-separated-values,text/plain", ".csv")
          ),
          # radioButtons("ob_upl_level", 
          #              "Level of obfuscation", 
          #              choiceNames = c("LARGE - Extremely Low Disclosure Risk", "MEDIUM - Low Disclosure Risk","SMALL - Minimal Disclosure Risk"),
          #              choiceValues = c("large","medium", "small"),
          #              # choiceNames = c("small", "medium", "large", "indepedent"),
          #              # choiceValues = c("small", "medium", "large", "indep"),
          #              selected = "small"
          # ),
          div(class = "button-group",
            actionButton("ob_upl_obf", "Obfuscate Uploaded Dataset",
                         style = "color: white;background-color: blue"),
            actionButton("ob_upl_reset", "Reset"),
            downloadButton("ob_upl_save", "Save"),
          ),
          hr(),
          div(class = "button-group",
              actionButton("ob_readme", "ReadMe/Help")
          )
        ),
        mainPanel(
          width = 9,
          h2(textOutput("ObfuscationTitle")),
          dataTableOutput('ob_table'),
          selectInput("ob_vl_select", "Distribution before/after obfuscation",
                      choices = c(),
                      multiple = TRUE
          ),
          actionButton("ob_vl_btn", "Plot"),
          uiOutput("ob_vl_plots")
        )
      ),
      # ----------------------- Data Augmentation Tab ----------------------- #
      tabPanel(
        title = paste0("Data Augmentation ", intToUtf8(0x0000226B)),
        sidebarPanel(
          width = 3,
          radioButtons("ag_level", 
                       "Level of Augmentation", 
                       choiceNames = c("30%", "50%", "200%"),
                       choiceValues = c("0.3", "0.5", "2"),
                       selected = "0.3"
          ),
          h3("Augment Synthetic Dataset (displayed)"),
          div(class = "button-group",
              actionButton("ag_syn_aug", "Augment Synthetic Dataset",
                           style = "color: white;background-color: blue"),
              actionButton("ag_syn_reset", "Reset"),
              downloadButton("ag_syn_save", "Save"),
          ),
          hr(),
          h3("Augment Uploaded Dataset (not displayed)"),
          fileInput(
            "ag_file",
            "Choose CSV File",
            accept = c("text/csv",
                       "text/comma-separated-values,text/plain", ".csv")
          ),
          div(class = "button-group",
              actionButton("ag_upl_aug", "Augment Uploaded Dataset",
                           style = "color: white;background-color: blue"),
              actionButton("ag_upl_reset", "Reset"),
              downloadButton("ag_upl_save", "Save"),
          ),
          hr(),
          div(class = "button-group",
              actionButton("ag_readme", "ReadMe/Help")
          )
        ),
        mainPanel(
          width = 9,
          h2("Augmented Data & Statistics"),
          dataTableOutput('ag_table'),
          plotOutput("FUN_Augmented")
        )
      )
      
    )
    
  ),
  
  # ----------------------- Footer ----------------------- #
  
  tags$footer(
    div(shinyUI(bootstrapPage(div(
      # include The SOCR footer HTML
      includeHTML("SOCR_footer_tracker.html")
    )))),
    div(
      "Version: V.0.1",
      align = 'center'
    ),
  )
)

##################################### End of UI ####################################

##################################### Server ####################################

server <- function(input, output, session) {
  # -------------------------- Reactive Values Data Flow -------------------------- #
  synData <- reactiveValues(Syn = NULL, Obf = NULL, Aug = NULL)
  uplData <- reactiveValues(Obf = NULL, Aug = NULL)
  prevData <- reactiveValues(Obf = NULL, Aug = NULL)
  observeEvent(synData$Syn, {
    synData$Obf <- synData$Syn
    synData$Aug <- synData$Syn
    prevData$Obf <- NULL
    prevData$Aug <- NULL
  })
  
  # !Temporary: Augmented data saved as value to replace saving as selected_data_aug.RData
  selected_data_aug_placeholder <- NULL
  
  # -------------------------- End of Reactive Values Data Flow -------------------------- #
  
  # -------------------------- Duplicate functions -------------------------- # 
  # Data table
  customDataTable <- function(dt) {
    datatable(
      dt, 
      rownames = FALSE,
      selection = "single", 
      filter = "top",
      callback = JS("$('#mytable').tooltip({selector:'[data-toggle=\"tooltip\"]'})"),
      escape = FALSE,
      options = list(
        scrollX = TRUE,
        autoWidth = TRUE,
        columnDefs = list(list(width = '150px', targets = "_all"))
      )
    )
  }
  # Download handler
  customDownloadHandler <- function(dt, prefix) {
    downloadHandler(
      filename = function() {
        paste0(prefix, "-", dim(dt)[1], "x", dim(dt)[2], ".csv")
      },
      content = function(file) {
        write.csv(dt, file, row.names = F)
      }
    )
  }
  # Violin plot
  customViolin <- function(dataset, feature) {
    fig <- plot_ly(
      type = 'violin',
      y = ~dataset[[feature]],
      box = list(
        visible = TRUE
      ),
      meanline = list(
        visible = TRUE
      ),
      x0 = if (nchar(feature) > 30) paste(substr(feature, 1, 27), "...", sep="") else feature
    )
    fig <- fig %>% layout(
      yaxis = list(
        title = "",
        zeroline = FALSE
      ),
      hovermode = 'compare'
    )
    fig
  }
  # Split violin plot
  customViolinSplit <- function(dt1, dt2, feature) {
    print(dt1)
    print(dt2)
    fig <- plot_ly(type = 'violin')  %>%
      add_trace(
        x = feature,
        y = ~dt1[[feature]],
        name = 'Before',
        side = 'negative',
        box = list(
          visible = T
        ),
        meanline = list(
          visible = T
        ),
        color = I("blue")
      ) 
    fig <- fig %>%
      add_trace(
        x = feature,
        y = ~dt2[[feature]],
        name = 'After',
        side = 'positive',
        box = list(
          visible = T
        ),
        meanline = list(
          visible = T
        ),
        color = I("green")
      ) 
    
    fig <- fig %>%
      layout(
        yaxis = list(
          title = "",
          zeroline = FALSE
        ),
        violinmode = 'overlay',
        hovermode = 'compare'
      )
    fig
  }
  
  # -------------------------- End of Duplicate functions -------------------------- # 
  
  observe({
    # -------------------------- Update UI -------------------------- #
    updateSelectizeInput(session, 
                         "icd9_selection", 
                         options = list(maxItems = input$K))
    })
  # utilityFunction()
  
  # -------------------------- Synthetic Generation (vh) Tab -------------------------- #
  ## -------------------- Synthetic Generation panel and table rendering --------------------- ##
  # Remember what tab(s) were enabled (to automatically select the newly enabled tab)
  vh_tabs_enabled <- NULL
  # Tab panel rendering with doctor notes and image options #
  # Respond to reactive value: input$vh_option
  output$Sythetic <- renderUI({
    panels <- list(
      tabPanel( title = "data",
                dataTableOutput('vh_table'),
                #mini tabs
                tabsetPanel(
                  #----   
                  tabPanel(
                    title = "Violin Plots",
                    selectInput("vh_vl_select", "Select features after generate your dataset",
                                choices = c(),
                                multiple = TRUE),
                    actionButton("vh_vl_btn", "Plot"),
                    uiOutput("vh_vl_plots")
                  )
                  # tabPanel(
                  #   title = "Bar Charts",
                  #   selectInput("vh_bc_select", "Select features after generate your dataset",
                  #               choices = c(),
                  #               multiple = TRUE),
                  #   actionButton("vh_bc_btn", "Plot"),
                  #   uiOutput("vh_bc_plots")
                  # )
                ),
      )        
    )

    if (length(input$vh_option) > 0) {
      if("dot" %in% input$vh_option){
        panels[[2]] <- tabPanel(title = "doctor notes",
                                value = "dot",
                                dataTableOutput('Notes_table'))
        if("img" %in% input$vh_option){
          panels[[3]] <-  tabPanel(title = "image",
                                   value = "img", 
                                   dataTableOutput('Image_table'))
        }
      }
      else if("img" %in% input$vh_option) {
        panels[[2]] <-  tabPanel(title = "image",
                                 value = "img",
                                 dataTableOutput('Image_table'))
      }
    }
    do.call(tabsetPanel, c(list(id = "vh_tabset"), panels))
  })
  
  # Automatically select the tab newly enabled
  observeEvent(input$vh_option, ignoreNULL = FALSE, {
    enable <- setdiff(input$vh_option, vh_tabs_enabled)
    if (length(enable) > 0) {
      updateTabsetPanel(session, "vh_tabset", selected = enable)
    }
    vh_tabs_enabled <<- input$vh_option
  })
  
  # Image table under "image" tab, if enabled #
  # Respond to reactive value: input_pic
  output$Image_table <- renderDataTable({
    
      dt <- input_pic()
      dt<-datatable(
        dt, 
        selection = "single", 
        filter = "top",
        callback = JS("$('#mytable').tooltip({selector:'[data-toggle=\"tooltip\"]'})"),
        escape = FALSE
      )
    
  })
  # Doctor notes table under "doctor notes" tab, if enabled #
  # Respond to reactive value: input_doc
  output$Notes_table <- renderDataTable({
  
    dt <- input_doc()

    dt<-datatable(
      dt, 
      selection = "single", 
      filter = "top",
      callback = JS("$('#mytable').tooltip({selector:'[data-toggle=\"tooltip\"]'})"),
      escape = FALSE
    )
  })
  
  # main data table under "data" tab #
  # Respond to reactive value: synData$Syn
  output$vh_table <- renderDataTable({
    dt <- synData$Syn
    
    # Update select input for plotting violin plots
    updateSelectInput(session = session,
                      inputId = "vh_vl_select",
                      label = "Select features to plot",
                      choices = names(dt)[-1],
                      selected = character(0)
    )
    # Update select input for plotting bar charts
    updateSelectInput(session = session,
                      inputId = "vh_bc_select",
                      label = "Select features to plot",
                      choices = names(dt)[-1],
                      selected = character(0)
    )
    customDataTable(dt)
  })
  
  ## -------------------- End of Synthetic Generation panel and table rendering --------------------- ##
  
  ## -------------------- Synthetic Generation generate button --------------------- ##
  input_doc <- eventReactive(
    input$vh_generate,{
      #selected_data <- data.frame(ID = 1:nrow(MIMIC_data_cont))
      selected_data <- data.frame(ID = 1:nrow(MIMIC_data))
      
      CDC_Doctor_Notes <- read.table("./data/CDC_notes.csv",stringsAsFactors = F,
                                     header = T, sep = "'")
      DoctorNotes_list <- sample(dim(CDC_Doctor_Notes)[1],input$N)
      doctor_notes <- NULL
      doctor_notes <- CDC_Doctor_Notes[DoctorNotes_list,1]
      
      
      dt <- data.frame(Doctor.notes = doctor_notes)
    })
  
  
  input_pic <- eventReactive(
    input$vh_generate,
    {
      img_uri <- function(x) { sprintf('<img src="%s" height="52"/>', knitr::image_uri(x))} 
      MRI_Images <- NULL
      MRI_list <- sample(9801,input$N) # I have 9801 MRI thumbnails stored as png
      #for (j in 1:input$N)  
      for (j in MRI_list)
      {
        eval(parse(text=paste0("MRI_Images <-c(MRI_Images,img_uri(\"./www/MRI_",j,".png\"))")))
    
      }
      dt <- data.frame(MRI_Images)
      
    })
  
  observeEvent(input$vh_generate,{
    row = input$N
    col = input$K
    
    # Error message for selecting too many features/patients (we should overcome this)
    validate(
      need(
        #row < nrow(MIMIC_data_cont),
        row < nrow(MIMIC_data),
        paste("Not that many patients in the database.")
      )
    )
    
    validate(
      need(
        #row < nrow(MIMIC_data_cont),
        col < ncol(MIMIC_data),
        paste("Not that many features in the database.")
      )
    )
    
    selected_data <- data.frame(ID = MIMIC_data[,1])
    selected_data_aug <- data.frame(ID = MIMIC_data[,1])
    # selected_data <- data.frame(ID = 1:nrow(MIMIC_data))
    # selected_data_aug <- data.frame(ID = 1:nrow(MIMIC_data))
    features <- match(input$icd9_selection, names(MIMIC_data))
    patients_temp <- sample(1:nrow(MIMIC_data), size = row)
    patients <- match(selected_data$ID[patients_temp], selected_data$ID)
    
    save(patients,features,file="Patients.Rdata")
    
    selected_data <- MIMIC_data[patients, features]
    selected_data <- type.convert(selected_data)
    
    rownames(selected_data)<-NULL
    # Here I add 4 sensitive fields with Charlatan
    Name <- ch_name(row)
    CreditCard <- ch_credit_card_number(row)
    Job <- ch_job(row)
    PhoneNumber <- ch_phone_number(row)
    selected_data <- selected_data %>% 
      add_column(Name, .before = 1) %>%
      add_column(CreditCard, .after = 1) %>%
      add_column(Job, .before = 2) %>%
      add_column(PhoneNumber, .after = 2)  %>%
      add_column(ID = MIMIC_data[patients,1], .before = 1)
#    add_column(ID = as.character(1:nrow(selected_data)), .before = 1)
    synData$Syn <- selected_data
  })
  ## -------------------- End of Synthetic Generation generate button --------------------- ##
  
  ## -------------------- Synthetic Generation render plots --------------------- ##
  
  # Render plots upon select changes
  observeEvent(input$vh_vl_btn, {
    output$vh_vl_plots <- renderUI({
      plot_outputs <- map(isolate(input$vh_vl_select), function(feature) {
        output[[paste("vh_vl", feature)]] <- renderPlotly({
          customViolin(isolate(synData$Syn), feature)
        })
        plotlyOutput(paste("vh_vl", feature))
      })
      do.call(tagList, plot_outputs)
    })
  })
  
  # Record features plotted last time to remove those handlers
  vh_bc_lastFeatures <- c()
  
  # Render plots upon select changes
  observeEvent(input$vh_bc_btn, {
    sapply(vh_bc_lastFeatures, function(lastFeature) {
      output[[paste("vh_bc", lastFeature)]] <- NULL
    })
    vh_vl_lastFeatures <<- c()
    
    output$vh_bc_plots <- renderUI({
      plot_outputs <- lapply(isolate(input$vh_bc_select), function(feature) {
        vh_bc_lastFeatures <<- c(vh_bc_lastFeatures, feature)
        output[[paste("vh_bc", feature)]] <- renderPlotly({
          dt <- isolate(synData$Syn)[[feature]]
          dt <- table(dt[!is.na(dt)])
          print(dt)
          fig <- plot_ly(
            x = ~names(dt),
            y = ~dt,
            type = 'bar',
            color = ~1:length(dt)
          )
          fig <- fig %>% layout(
            xaxis = list(
              type = "array",
              categoryarray = names(dt),
              title = if (nchar(feature) > 30) paste(substr(feature, 1, 27), "...", sep="") else feature,
              titlefont = list(size = 12)
            ),
            yaxis = list(
              title = "Count",
              titlefont = list(size = 12)
            ),
            hovermode = 'compare'
          ) 
          fig <- fig %>% hide_colorbar()
          fig
        })
        plotlyOutput(paste("vh_bc", feature))
      })
      do.call(tagList, plot_outputs)
    })
  })
  ## -------------------- End of Synthetic Generation render plots --------------------- ##
  
  ## -------------------- Synthetic Generation other buttons --------------------- ##
  # Help-me button #
  observeEvent(input$vh_readme, {
    showModal(modalDialog(
      title = "Help / ReadMe",
      HTML('<div>
             <font size="3"><font color="blue"><b>GrayRain [Version: V.0.1]</b></font></font> designs innovative tools, builds effective AI services, 
             and promotes large-scale data-driven health analytics.
             <br /><br /><br />
             Our tools are driven by the core principle that rapid, secure, 
             and efficient data-sharing between organizations and within
             organizations increases productivity and facilitates knowledge
             generation and translation into clinical practice to improve human conditions.
             <br /><br /><br />
             The <b>VirtualHospital App</b> provides three complementary services:
             <br /><br />
             o   <b>Synthetic Patients Generation</b> - used to generate heterogeneous simulated datasets
             <br /><br />
             o   <b>Data Obfuscation</b> - used to statistically obfuscate existent clinical data and 
                 balance the risk of patient de-identification and the value of the data utility
             <br /><br />
             o   <b>Data Augmentation</b> - used to augment and append existing data archives to increase
                 the number of cases and enrich the feature characteristics
             <br /><br /><br /> 
             Data governors, healthcare providers, insurance companies, researchers,
             data analysts, and ITC managers can contact GrayRain for product customizations
             tailored to their specific needs.
             <br /><br /><br />
             <div align="center">
             <font size="3"><b>Developers</b><br /></font></div>
             <font size="2">Simeone Marino (<b>simeonem@umich.edu</b>),
             Ka Yu Wong (kayuw@umich.edu),Benjamin Danzig (<b>bdanzig@umich.edu</b>),
             Fuhan Shen (<b>fuhan@umich.edu</b>),Roland Park (<b>parkro@umich.edu</b>),
             Ivo Dinov (<b>dinov@med.umich.edu</b>).</font>
             <br /><br />
             <font size="3"><font color="blue"><b>URL:<font color="blue"> www.grayrain.org</font></b><br /><br />
             <b>Email:<font color="blue"><b> info@grayrain.org</b></font>
             '),
      
      easyClose = TRUE
    ))
  })

  # Save button #
  output$vh_save <- output$vh_save <- customDownloadHandler(isolate(synData$Syn), "vh")
  
  # Reset button #
  observeEvent(input$vh_reset, {
    updateSelectizeInput(session, "icd9_selection", selected = character())
  })
  
  # !Temporary: select all button #
  observeEvent(input$vh_selectAll, {
    updateSelectizeInput(session, "icd9_selection", selected = itemColName)
  })
  
  ## -------------------- End of Synthetic Generation other buttons --------------------- ##
  # -------------------------- End of Synthetic Generation Tab-------------------------- #
  
  
  # --------------------------------- Obfuscation Tab --------------------------------- #
  
  ## ---------------------- Obfuscation Tab Title ---------------------- ##
  output$ObfuscationTitle <- renderText({
      if(input$ob_syn_level=="small"){risk="[less than 10%]"}
      if(input$ob_syn_level=="medium"){risk="[less than 5%]"}
      if(input$ob_syn_level=="large"){risk="[less than 1%]"}
      outputString <- paste("Obfuscation / Disclosure Risks = ",risk)
      #outputString <- paste("Obfuscation / Disclosure Risks = ",input$ob_syn_level)
    outputString
  })
  ## ---------------------- End of Obfuscation Tab Title ---------------------- ##
  
  ## ---------------------- Obfuscation table rendering ---------------------- ##
  # Respond to reactive value: synData$Obf
  output$ob_table <- renderDataTable({
    dt <- synData$Obf
    updateSelectInput(session = session,
                      inputId = "ob_vl_select", 
                      choices = names(dt)[-1],
                      selected = isolate(input$ob_vl_select)
    )
    customDataTable(dt)
  })
  
  ## ---------------------- End of Obfuscation table rendering ---------------------- ##
  
  ## ---------------------- Obfuscation upload file ---------------------- ##
  observeEvent(input$ob_file, {
    inFile <- input$ob_file
    if (!is.null(inFile)) {
      uplData$Obf <- read.table(inFile$datapath,
                                 header = T, 
                                 sep = "," ,
                                 stringsAsFactors = T)
    }
  })
  
  ## ---------------------- End of Obfuscation upload file ---------------------- ##
  
  ## ---------------------- Obfuscation function ---------------------- ##
  obfuscateData <- function(RawData, level) {
    shiny::validate(
      need(
        !is.null(RawData),
        "No data to obfuscate"
      )
    )
    #print(RawData)
    #load(MIMIC_1000_199,unstructured_list,file = "MIMIC_1000_199.RData")
    
    #load("MIMIC_1000_199.RData")
    
    #names(RawData) <- chartr(".", " ", names(RawData))
    #sub("."," ",names(RawData), fixed = T)
    #aq <- match(intersect(names(RawData),names(MIMIC_1000_199)[unstructured_list]),names(RawData))
    #ifelse(!is.na(aq),unstructured_labels <- names(RawData)[aq],unstructured_labels <- NULL)
    
    sensitive_cols <- c(2:5)
    data_temp <- RawData
    data_temp = data_temp[, -sensitive_cols]
    names_for_sifted_data <- names(data_temp)
    #names(data_temp) <- c("Patient ID",  paste0("V",1:(dim(data_temp)[2]-1)))
    # SiftedData <- dataSifter(level = level,
    #                          data = data_temp[, -1],
    #                          batchsubj = dim(data_temp)[1],
    #                          maxiter = 1,
    #                          nomissing = T,
    #                          usecore = 1)#,unstructured.names = unstructured_labels)
    SiftedData <- dataSifter(level = level,
                             data = data_temp[, -1],
                             batchsubj = min(200, (dim(data_temp)[1])/2),
                             maxiter = 1,
                             nomissing = T,
                             usecore = 2)#,unstructured.names = unstructured_labels)
    
    ## Add back the same sensitive nformation/fields but obfuscated
    # Here I add 2 or 3 sensitive fields with Charlatan
    num_rows <- dim(SiftedData)[1]
    Name <- ch_name(num_rows)
    CreditCard <- ch_credit_card_number(num_rows) 
    Job <- ch_job(num_rows)
    PhoneNumber <- ch_phone_number(num_rows)
    SiftedData <- add_column(SiftedData, Name, .before = 1)
    SiftedData <- add_column(SiftedData, CreditCard, .after = 1)
    SiftedData <- add_column(SiftedData, Job, .before = 2)
    SiftedData <- add_column(SiftedData, PhoneNumber, .after = 2)
    SiftedData <- add_column(SiftedData, ID = as.character(1:nrow(SiftedData)), .before = 1)
    return(SiftedData)
  }
  ## ---------------------- End of Obfuscation function ---------------------- ##
  
  ## ---------------------- Obfuscation upload section ---------------------- ##
  # Obfuscate button #
  observeEvent(input$ob_upl_obf, {
    prevData$Obf <- uplData$Obf
    uplData$Obf <- obfuscateData(uplData$Obf, input$ob_syn_level)
    synData$Obf <- uplData$Obf
  })
  
  # Save button #
  output$ob_upl_save <- customDownloadHandler(isolate(uplData$Obf), "ob")
  
  ## ---------------------- End of Obfuscation upload portion ---------------------- ##
  
  ## ---------------------- Obfuscation synthetic section ---------------------- ##
  # Obfuscate button #
  observeEvent(input$ob_syn_obf, {
    prevData$Obf <- synData$Obf
    synData$Obf <- obfuscateData(synData$Obf, input$ob_syn_level)
  })
  
  # Save button #
  output$ob_syn_save <- customDownloadHandler(isolate(synData$Obf), "ob")
  
  ## ---------------------- End of Obfuscation synthetic section ---------------------- ##
  
  ## ---------------------- Obfuscation plot rendering ---------------------- ##
  
  obRenderPlot <- function() {
    before <- isolate(prevData$Obf)
    after <- isolate(synData$Obf)
    if (is.null(before) || is.null(after)) return()
    output$ob_vl_plots <- renderUI({
      plot_outputs <- map(isolate(input$ob_vl_select), function(feature) {
        output[[paste("ob_vl", feature)]] <- renderPlotly({
          customViolinSplit(before, after, feature)
        })
        plotlyOutput(paste("ob_vl", feature))
      })
      do.call(tagList, plot_outputs)
    })
  }
  
  observeEvent(input$ob_vl_btn, {
    obRenderPlot()
  })
  
  ## ---------------------- End of Obfuscation plot rendering ---------------------- ##
  
  ## -------------------- Obfuscation other buttons --------------------- ##
  # Obfuscate Help me button #
  observeEvent(input$ob_readme, {
    showModal(modalDialog(
      title = "Help / ReadMe",
      HTML('<div>
             ... Obfuscate Read Me. More to come ... <br />
             ...
             <br />
             '),
      HTML(
        '<br/> <div align="center">
                 <a href="http://socr.umich.edu/HTML5/"><b>SOCR Apps</b></a> </div>'
      ),
      easyClose = TRUE
    ))
  })
  
  ## -------------------- End of Obfuscation other buttons --------------------- ##

  # ------------------------------ End of Obfuscation Tab ------------------------------ #

  
  # -------------------------------- Augmentation Tab ------------------------------- #
  
  ## ---------------------- Augmentation table rendering ---------------------- ##
  # Respond to reactive value: synData$Aug
  output$ag_table <- renderDataTable({
    customDataTable(synData$Aug)
  })
  ## ---------------------- End of Augmentation table rendering ---------------------- ##
  
  ## ---------------------- Augmentation upload file ---------------------- ##
  # Respond to reactive value: input$ag_file
  observeEvent(input$ag_file, {
    inFile <- input$ag_file
    if (!is.null(inFile)) {
      uplData$Aug <- read.table(inFile$datapath,
                                 header = T, 
                                 sep = "," ,
                                 stringsAsFactors = T)
    }
  })
  ## ---------------------- End of Augmentation upload file ---------------------- ##
  
  ## ---------------------- Augmentation function ---------------------- ##
  # Augment button #
  augmentData <- function(RawData, expand) {
    validate(
      need(
        !is.null(RawData),
        "No data to augment"
      )
    )
    expand <- as.numeric(expand)
    load("Patients.Rdata")
    rawRow <- nrow(RawData)
    rawCol <- ncol(RawData)
    RawData <- RawData[, -1] # delete ID column
    features_selected <- match(names(RawData), names(MIMIC_data))
    features_selected <- features_selected[!is.na(features_selected)]
    max_features_size <- (dim(MIMIC_data)[2] - 1) - length(features_selected)
    features_new <- sample(1:ncol(MIMIC_data)[-features_selected], 
                           size = as.integer(min(rawCol * expand , max_features_size))) 
    features_all <- c(features_selected, features_new)
    
    # Note: Just for demo purpose; new column data for old rows are not from original rows
    # sideRows <- sample(nrow(MIMIC_data), size = rawRow) 
    # downRows <- sample(nrow(MIMIC_data), size = rawRow * expand)
    
    max_patient_size <- dim(MIMIC_data)[1] - length(patients)
    patients_temp_aug <- sample(1:nrow(MIMIC_data)[-patients], 
                                size = as.integer(min(max_patient_size , rawRow * expand)))
    newRows <- c(patients,patients_temp_aug)

    Name <- ch_name(length(newRows))
    CreditCard <- ch_credit_card_number(length(newRows))
    Job <- ch_job(length(newRows))
    PhoneNumber <- ch_phone_number(length(newRows))
    
    # downData <- MIMIC_data[downRows, features_all] %>% 
    #   add_column(Name, .before = 1) %>%
    #   add_column(CreditCard, .after = 1) %>%
    #   add_column(Job, .before = 2) %>%
    #   add_column(PhoneNumber, .after = 2)
    
    # augmented_data <- RawData %>%
    #   cbind(MIMIC_data[sideRows, features_new]) %>%
    #   rbind(downData) %>%
    #   add_column(ID = as.character(1:(rawRow + newRows)), .before = 1) %>%
    #   type.convert()

    augmented_data <- MIMIC_data[newRows,features_all] %>%
      add_column(Name, .before = 1) %>%
      add_column(CreditCard, .after = 1) %>%
      add_column(Job, .before = 2) %>%
      add_column(PhoneNumber, .after = 2) %>%
      add_column(ID = as.character(MIMIC_data[newRows,1]), .before = 1) %>%
      type.convert()
    
    return(augmented_data)
    
  }
  
  ## ---------------------- End of Augmentation function ---------------------- ##
  
  ## ---------------------- Augmentation upload section ---------------------- ##
  # Augment button #
  observeEvent(input$ag_upl_aug, {
    uplData$Aug <- augmentData(uplData$Aug, input$ag_level)
  })
  
  # Save button #
  output$ag_upl_save <- customDownloadHandler(isolate(uplData$Aug), "ag")
  
  ## ---------------------- End of Augmentation upload portion ---------------------- ##
  
  ## ---------------------- Augmentation synthetic section ---------------------- ##
  # Augment button #
  observeEvent(input$ag_syn_aug, {
    synData$Aug <- augmentData(synData$Aug, input$ag_level)
  })
  # Save button #
  output$ag_syn_save <- customDownloadHandler(isolate(synData$Aug), "ag")
  
  ## ---------------------- End of Augmentation synthetic section ---------------------- ##
  
  ## -------------------- Augmentation other buttons --------------------- ##
  
  # Augment Help me button #
  observeEvent(input$ag_readme, {
    showModal(modalDialog(
      title = "Help / ReadMe",
      HTML('<div>
             ... Obfuscate Read Me. More to come ... <br />
             ...
             <br />
             '),
      HTML(
        '<br/> <div align="center">
                 <a href="http://socr.umich.edu/HTML5/"><b>SOCR Apps</b></a> </div>'
      ),
      easyClose = TRUE
    ))
  })

  ## -------------------- Augmentation other buttons --------------------- ##
  
  # -------------------------------- End of Augmentation Tab ------------------------------- #
}

##################################### End of Server ####################################

# Run the application
shinyApp(ui = ui, server = server)

# Deploy app
# library(rsconnect)
#rsconnect::deployApp()
# rsconnect::deployApp('VH_v1.0.R')
# rsconnect::deployApp('RShinyApp_PIPM/PIPM_SA_V2.0.R')
